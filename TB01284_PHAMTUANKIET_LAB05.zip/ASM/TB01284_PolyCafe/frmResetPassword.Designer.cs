﻿namespace TB01284_PolyCafe
{
    partial class frmResetPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbut_HTMatKhauMoi = new System.Windows.Forms.RadioButton();
            this.rbut_HTXacNhanMatKhau = new System.Windows.Forms.RadioButton();
            this.rbut_HTMatKhauCu = new System.Windows.Forms.RadioButton();
            this.but_ThoatDoiMatKhau = new System.Windows.Forms.Button();
            this.but_DoiMatKhau = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_MatKhauCu = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_TenTaKhoanDoiMatKhau = new System.Windows.Forms.TextBox();
            this.txt_XacNhanMatKhau = new System.Windows.Forms.TextBox();
            this.txt_MatKhauMoi = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // rbut_HTMatKhauMoi
            // 
            this.rbut_HTMatKhauMoi.AutoSize = true;
            this.rbut_HTMatKhauMoi.Location = new System.Drawing.Point(710, 313);
            this.rbut_HTMatKhauMoi.Name = "rbut_HTMatKhauMoi";
            this.rbut_HTMatKhauMoi.Size = new System.Drawing.Size(72, 20);
            this.rbut_HTMatKhauMoi.TabIndex = 29;
            this.rbut_HTMatKhauMoi.TabStop = true;
            this.rbut_HTMatKhauMoi.Text = "Hiển thị";
            this.rbut_HTMatKhauMoi.UseVisualStyleBackColor = true;
            this.rbut_HTMatKhauMoi.CheckedChanged += new System.EventHandler(this.rbut_HTMatKhauMoi_CheckedChanged);
            // 
            // rbut_HTXacNhanMatKhau
            // 
            this.rbut_HTXacNhanMatKhau.AutoSize = true;
            this.rbut_HTXacNhanMatKhau.Location = new System.Drawing.Point(710, 381);
            this.rbut_HTXacNhanMatKhau.Name = "rbut_HTXacNhanMatKhau";
            this.rbut_HTXacNhanMatKhau.Size = new System.Drawing.Size(72, 20);
            this.rbut_HTXacNhanMatKhau.TabIndex = 28;
            this.rbut_HTXacNhanMatKhau.TabStop = true;
            this.rbut_HTXacNhanMatKhau.Text = "Hiển thị";
            this.rbut_HTXacNhanMatKhau.UseVisualStyleBackColor = true;
            this.rbut_HTXacNhanMatKhau.CheckedChanged += new System.EventHandler(this.rbut_HTXacNhanMatKhau_CheckedChanged);
            // 
            // rbut_HTMatKhauCu
            // 
            this.rbut_HTMatKhauCu.AutoSize = true;
            this.rbut_HTMatKhauCu.Location = new System.Drawing.Point(710, 246);
            this.rbut_HTMatKhauCu.Name = "rbut_HTMatKhauCu";
            this.rbut_HTMatKhauCu.Size = new System.Drawing.Size(72, 20);
            this.rbut_HTMatKhauCu.TabIndex = 27;
            this.rbut_HTMatKhauCu.TabStop = true;
            this.rbut_HTMatKhauCu.Text = "Hiển thị";
            this.rbut_HTMatKhauCu.UseVisualStyleBackColor = true;
            this.rbut_HTMatKhauCu.CheckedChanged += new System.EventHandler(this.rbut_HTMatKhauCu_CheckedChanged);
            // 
            // but_ThoatDoiMatKhau
            // 
            this.but_ThoatDoiMatKhau.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.but_ThoatDoiMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_ThoatDoiMatKhau.Location = new System.Drawing.Point(579, 445);
            this.but_ThoatDoiMatKhau.Name = "but_ThoatDoiMatKhau";
            this.but_ThoatDoiMatKhau.Size = new System.Drawing.Size(203, 43);
            this.but_ThoatDoiMatKhau.TabIndex = 26;
            this.but_ThoatDoiMatKhau.Text = "Thoát";
            this.but_ThoatDoiMatKhau.UseVisualStyleBackColor = false;
            this.but_ThoatDoiMatKhau.Click += new System.EventHandler(this.but_ThoatDoiMatKhau_Click);
            // 
            // but_DoiMatKhau
            // 
            this.but_DoiMatKhau.BackColor = System.Drawing.Color.DarkSalmon;
            this.but_DoiMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_DoiMatKhau.Location = new System.Drawing.Point(166, 445);
            this.but_DoiMatKhau.Name = "but_DoiMatKhau";
            this.but_DoiMatKhau.Size = new System.Drawing.Size(203, 43);
            this.but_DoiMatKhau.TabIndex = 25;
            this.but_DoiMatKhau.Text = "Đổi mật khẩu";
            this.but_DoiMatKhau.UseVisualStyleBackColor = false;
            this.but_DoiMatKhau.Click += new System.EventHandler(this.but_DoiMatKhau_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(200, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 20);
            this.label5.TabIndex = 24;
            this.label5.Text = "Mật khẩu cũ:";
            // 
            // txt_MatKhauCu
            // 
            this.txt_MatKhauCu.Location = new System.Drawing.Point(422, 244);
            this.txt_MatKhauCu.Name = "txt_MatKhauCu";
            this.txt_MatKhauCu.ReadOnly = true;
            this.txt_MatKhauCu.Size = new System.Drawing.Size(276, 22);
            this.txt_MatKhauCu.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(383, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(211, 41);
            this.label4.TabIndex = 22;
            this.label4.Text = "Đổi mật khẩu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(200, 379);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 20);
            this.label3.TabIndex = 21;
            this.label3.Text = "Xác nhận mật khẩu:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(200, 314);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "Mật khẩu mới:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(200, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 19;
            this.label1.Text = "Tên tài khoản:";
            // 
            // txt_TenTaKhoanDoiMatKhau
            // 
            this.txt_TenTaKhoanDoiMatKhau.Location = new System.Drawing.Point(422, 177);
            this.txt_TenTaKhoanDoiMatKhau.Name = "txt_TenTaKhoanDoiMatKhau";
            this.txt_TenTaKhoanDoiMatKhau.ReadOnly = true;
            this.txt_TenTaKhoanDoiMatKhau.Size = new System.Drawing.Size(276, 22);
            this.txt_TenTaKhoanDoiMatKhau.TabIndex = 18;
            // 
            // txt_XacNhanMatKhau
            // 
            this.txt_XacNhanMatKhau.Location = new System.Drawing.Point(422, 379);
            this.txt_XacNhanMatKhau.Name = "txt_XacNhanMatKhau";
            this.txt_XacNhanMatKhau.Size = new System.Drawing.Size(276, 22);
            this.txt_XacNhanMatKhau.TabIndex = 17;
            // 
            // txt_MatKhauMoi
            // 
            this.txt_MatKhauMoi.Location = new System.Drawing.Point(422, 312);
            this.txt_MatKhauMoi.Name = "txt_MatKhauMoi";
            this.txt_MatKhauMoi.Size = new System.Drawing.Size(276, 22);
            this.txt_MatKhauMoi.TabIndex = 16;
            // 
            // frmResetPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(949, 566);
            this.Controls.Add(this.rbut_HTMatKhauMoi);
            this.Controls.Add(this.rbut_HTXacNhanMatKhau);
            this.Controls.Add(this.rbut_HTMatKhauCu);
            this.Controls.Add(this.but_ThoatDoiMatKhau);
            this.Controls.Add(this.but_DoiMatKhau);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_MatKhauCu);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_TenTaKhoanDoiMatKhau);
            this.Controls.Add(this.txt_XacNhanMatKhau);
            this.Controls.Add(this.txt_MatKhauMoi);
            this.Name = "frmResetPassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmResetPassword";
            this.Load += new System.EventHandler(this.frmResetPassword_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbut_HTMatKhauMoi;
        private System.Windows.Forms.RadioButton rbut_HTXacNhanMatKhau;
        private System.Windows.Forms.RadioButton rbut_HTMatKhauCu;
        private System.Windows.Forms.Button but_ThoatDoiMatKhau;
        private System.Windows.Forms.Button but_DoiMatKhau;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_MatKhauCu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_TenTaKhoanDoiMatKhau;
        private System.Windows.Forms.TextBox txt_XacNhanMatKhau;
        private System.Windows.Forms.TextBox txt_MatKhauMoi;
    }
}