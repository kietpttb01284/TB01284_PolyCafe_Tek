﻿namespace TB01284_PolyCafe
{
    partial class frmPhieuBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PhieuBanHang = new System.Windows.Forms.TabControl();
            this.TabPhieuBanHang = new System.Windows.Forms.TabPage();
            this.butXoa = new System.Windows.Forms.Button();
            this.butTimKiem = new System.Windows.Forms.Button();
            this.butLamMoi = new System.Windows.Forms.Button();
            this.butSua = new System.Windows.Forms.Button();
            this.butThem = new System.Windows.Forms.Button();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TPNgayTao = new System.Windows.Forms.DateTimePicker();
            this.rbutChoXacNhan = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMaKhachHang = new System.Windows.Forms.TextBox();
            this.txtMaNhanVien = new System.Windows.Forms.TextBox();
            this.txtMaThe = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMaPhieu = new System.Windows.Forms.TextBox();
            this.DataPhieuBanHang = new System.Windows.Forms.DataGridView();
            this.TabChiTietPhieu = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.butTimKiem2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.butTthem = new System.Windows.Forms.Button();
            this.txtTimKiem2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.DataChiTietPhieu = new System.Windows.Forms.DataGridView();
            this.PhieuBanHang.SuspendLayout();
            this.TabPhieuBanHang.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataPhieuBanHang)).BeginInit();
            this.TabChiTietPhieu.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataChiTietPhieu)).BeginInit();
            this.SuspendLayout();
            // 
            // PhieuBanHang
            // 
            this.PhieuBanHang.Controls.Add(this.TabPhieuBanHang);
            this.PhieuBanHang.Controls.Add(this.TabChiTietPhieu);
            this.PhieuBanHang.Location = new System.Drawing.Point(1, 1);
            this.PhieuBanHang.Name = "PhieuBanHang";
            this.PhieuBanHang.SelectedIndex = 0;
            this.PhieuBanHang.Size = new System.Drawing.Size(1241, 604);
            this.PhieuBanHang.TabIndex = 0;
            // 
            // TabPhieuBanHang
            // 
            this.TabPhieuBanHang.BackColor = System.Drawing.Color.FloralWhite;
            this.TabPhieuBanHang.Controls.Add(this.butXoa);
            this.TabPhieuBanHang.Controls.Add(this.butTimKiem);
            this.TabPhieuBanHang.Controls.Add(this.butLamMoi);
            this.TabPhieuBanHang.Controls.Add(this.butSua);
            this.TabPhieuBanHang.Controls.Add(this.butThem);
            this.TabPhieuBanHang.Controls.Add(this.txtTimKiem);
            this.TabPhieuBanHang.Controls.Add(this.label10);
            this.TabPhieuBanHang.Controls.Add(this.groupBox1);
            this.TabPhieuBanHang.Controls.Add(this.DataPhieuBanHang);
            this.TabPhieuBanHang.Location = new System.Drawing.Point(4, 25);
            this.TabPhieuBanHang.Name = "TabPhieuBanHang";
            this.TabPhieuBanHang.Padding = new System.Windows.Forms.Padding(3);
            this.TabPhieuBanHang.Size = new System.Drawing.Size(1233, 575);
            this.TabPhieuBanHang.TabIndex = 0;
            this.TabPhieuBanHang.Text = "Phiếu bán hàng";
            // 
            // butXoa
            // 
            this.butXoa.Location = new System.Drawing.Point(28, 508);
            this.butXoa.Name = "butXoa";
            this.butXoa.Size = new System.Drawing.Size(156, 47);
            this.butXoa.TabIndex = 25;
            this.butXoa.Text = "Xóa";
            this.butXoa.UseVisualStyleBackColor = true;
            // 
            // butTimKiem
            // 
            this.butTimKiem.Location = new System.Drawing.Point(825, 24);
            this.butTimKiem.Name = "butTimKiem";
            this.butTimKiem.Size = new System.Drawing.Size(99, 35);
            this.butTimKiem.TabIndex = 24;
            this.butTimKiem.Text = "Tìm kiếm";
            this.butTimKiem.UseVisualStyleBackColor = true;
            // 
            // butLamMoi
            // 
            this.butLamMoi.Location = new System.Drawing.Point(244, 508);
            this.butLamMoi.Name = "butLamMoi";
            this.butLamMoi.Size = new System.Drawing.Size(156, 47);
            this.butLamMoi.TabIndex = 23;
            this.butLamMoi.Text = "Làm mới";
            this.butLamMoi.UseVisualStyleBackColor = true;
            // 
            // butSua
            // 
            this.butSua.Location = new System.Drawing.Point(244, 441);
            this.butSua.Name = "butSua";
            this.butSua.Size = new System.Drawing.Size(156, 47);
            this.butSua.TabIndex = 22;
            this.butSua.Text = "Sửa";
            this.butSua.UseVisualStyleBackColor = true;
            // 
            // butThem
            // 
            this.butThem.Location = new System.Drawing.Point(28, 441);
            this.butThem.Name = "butThem";
            this.butThem.Size = new System.Drawing.Size(156, 47);
            this.butThem.TabIndex = 21;
            this.butThem.Text = "Thêm";
            this.butThem.UseVisualStyleBackColor = true;
            // 
            // txtTimKiem
            // 
            this.txtTimKiem.Location = new System.Drawing.Point(930, 30);
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(271, 22);
            this.txtTimKiem.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Sienna;
            this.label10.Location = new System.Drawing.Point(324, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(228, 32);
            this.label10.TabIndex = 20;
            this.label10.Text = "Phiếu bán hàng";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TPNgayTao);
            this.groupBox1.Controls.Add(this.rbutChoXacNhan);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtMaKhachHang);
            this.groupBox1.Controls.Add(this.txtMaNhanVien);
            this.groupBox1.Controls.Add(this.txtMaThe);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtMaPhieu);
            this.groupBox1.Location = new System.Drawing.Point(6, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(443, 339);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin phiếu bán hàng";
            // 
            // TPNgayTao
            // 
            this.TPNgayTao.Location = new System.Drawing.Point(174, 292);
            this.TPNgayTao.Name = "TPNgayTao";
            this.TPNgayTao.Size = new System.Drawing.Size(249, 22);
            this.TPNgayTao.TabIndex = 13;
            // 
            // rbutChoXacNhan
            // 
            this.rbutChoXacNhan.AutoSize = true;
            this.rbutChoXacNhan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbutChoXacNhan.Location = new System.Drawing.Point(174, 247);
            this.rbutChoXacNhan.Name = "rbutChoXacNhan";
            this.rbutChoXacNhan.Size = new System.Drawing.Size(120, 22);
            this.rbutChoXacNhan.TabIndex = 12;
            this.rbutChoXacNhan.TabStop = true;
            this.rbutChoXacNhan.Text = "Chờ xác nhận";
            this.rbutChoXacNhan.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(302, 247);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(121, 22);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Đã thanh toán";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(18, 294);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Ngày tạo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(18, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Trạng thái:";
            // 
            // txtMaKhachHang
            // 
            this.txtMaKhachHang.Location = new System.Drawing.Point(172, 193);
            this.txtMaKhachHang.Name = "txtMaKhachHang";
            this.txtMaKhachHang.Size = new System.Drawing.Size(251, 22);
            this.txtMaKhachHang.TabIndex = 8;
            // 
            // txtMaNhanVien
            // 
            this.txtMaNhanVien.Location = new System.Drawing.Point(174, 142);
            this.txtMaNhanVien.Name = "txtMaNhanVien";
            this.txtMaNhanVien.Size = new System.Drawing.Size(251, 22);
            this.txtMaNhanVien.TabIndex = 7;
            // 
            // txtMaThe
            // 
            this.txtMaThe.Location = new System.Drawing.Point(174, 86);
            this.txtMaThe.Name = "txtMaThe";
            this.txtMaThe.Size = new System.Drawing.Size(249, 22);
            this.txtMaThe.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Mã khách hàng:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Mã nhân viên:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Mã thẻ:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Mã phiếu:";
            // 
            // txtMaPhieu
            // 
            this.txtMaPhieu.Location = new System.Drawing.Point(174, 37);
            this.txtMaPhieu.Name = "txtMaPhieu";
            this.txtMaPhieu.Size = new System.Drawing.Size(249, 22);
            this.txtMaPhieu.TabIndex = 1;
            // 
            // DataPhieuBanHang
            // 
            this.DataPhieuBanHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataPhieuBanHang.Location = new System.Drawing.Point(475, 83);
            this.DataPhieuBanHang.Name = "DataPhieuBanHang";
            this.DataPhieuBanHang.RowHeadersWidth = 51;
            this.DataPhieuBanHang.RowTemplate.Height = 24;
            this.DataPhieuBanHang.Size = new System.Drawing.Size(751, 484);
            this.DataPhieuBanHang.TabIndex = 3;
            this.DataPhieuBanHang.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataPhieuBanHang_CellContentDoubleClick);
            // 
            // TabChiTietPhieu
            // 
            this.TabChiTietPhieu.BackColor = System.Drawing.Color.FloralWhite;
            this.TabChiTietPhieu.Controls.Add(this.button1);
            this.TabChiTietPhieu.Controls.Add(this.butTimKiem2);
            this.TabChiTietPhieu.Controls.Add(this.button3);
            this.TabChiTietPhieu.Controls.Add(this.button4);
            this.TabChiTietPhieu.Controls.Add(this.butTthem);
            this.TabChiTietPhieu.Controls.Add(this.txtTimKiem2);
            this.TabChiTietPhieu.Controls.Add(this.label7);
            this.TabChiTietPhieu.Controls.Add(this.groupBox2);
            this.TabChiTietPhieu.Controls.Add(this.DataChiTietPhieu);
            this.TabChiTietPhieu.Location = new System.Drawing.Point(4, 25);
            this.TabChiTietPhieu.Name = "TabChiTietPhieu";
            this.TabChiTietPhieu.Padding = new System.Windows.Forms.Padding(3);
            this.TabChiTietPhieu.Size = new System.Drawing.Size(1233, 575);
            this.TabChiTietPhieu.TabIndex = 1;
            this.TabChiTietPhieu.Text = "Chi tiết phiếu bán hàng";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(45, 472);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 47);
            this.button1.TabIndex = 34;
            this.button1.Text = "Xóa";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // butTimKiem2
            // 
            this.butTimKiem2.Location = new System.Drawing.Point(825, 18);
            this.butTimKiem2.Name = "butTimKiem2";
            this.butTimKiem2.Size = new System.Drawing.Size(99, 35);
            this.butTimKiem2.TabIndex = 33;
            this.butTimKiem2.Text = "Tìm kiếm";
            this.butTimKiem2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(261, 472);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(148, 47);
            this.button3.TabIndex = 32;
            this.button3.Text = "Làm mới";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(261, 405);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(148, 47);
            this.button4.TabIndex = 31;
            this.button4.Text = "Sửa";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // butTthem
            // 
            this.butTthem.Location = new System.Drawing.Point(45, 405);
            this.butTthem.Name = "butTthem";
            this.butTthem.Size = new System.Drawing.Size(148, 47);
            this.butTthem.TabIndex = 30;
            this.butTthem.Text = "Thêm";
            this.butTthem.UseVisualStyleBackColor = true;
            // 
            // txtTimKiem2
            // 
            this.txtTimKiem2.Location = new System.Drawing.Point(930, 24);
            this.txtTimKiem2.Name = "txtTimKiem2";
            this.txtTimKiem2.Size = new System.Drawing.Size(271, 22);
            this.txtTimKiem2.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Sienna;
            this.label7.Location = new System.Drawing.Point(343, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(195, 32);
            this.label7.TabIndex = 29;
            this.label7.Text = "Chi tiết phiếu";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Location = new System.Drawing.Point(16, 77);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(443, 286);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin phiếu bán hàng";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(172, 242);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(251, 22);
            this.textBox1.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(17, 242);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 20);
            this.label8.TabIndex = 9;
            this.label8.Text = "Thành tiền:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(172, 193);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(251, 22);
            this.textBox2.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(174, 142);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(251, 22);
            this.textBox3.TabIndex = 7;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(174, 86);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(249, 22);
            this.textBox4.TabIndex = 6;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(17, 193);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 20);
            this.label11.TabIndex = 5;
            this.label11.Text = "Đơn giá:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(17, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 20);
            this.label12.TabIndex = 4;
            this.label12.Text = "Số lượng:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(20, 86);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(115, 20);
            this.label13.TabIndex = 3;
            this.label13.Text = "Mã sản phẩm:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(20, 35);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 20);
            this.label14.TabIndex = 2;
            this.label14.Text = "Mã phiếu:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(174, 37);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(249, 22);
            this.textBox5.TabIndex = 1;
            // 
            // DataChiTietPhieu
            // 
            this.DataChiTietPhieu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataChiTietPhieu.Location = new System.Drawing.Point(475, 77);
            this.DataChiTietPhieu.Name = "DataChiTietPhieu";
            this.DataChiTietPhieu.RowHeadersWidth = 51;
            this.DataChiTietPhieu.RowTemplate.Height = 24;
            this.DataChiTietPhieu.Size = new System.Drawing.Size(751, 484);
            this.DataChiTietPhieu.TabIndex = 26;
            // 
            // frmPhieuBanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(1243, 605);
            this.Controls.Add(this.PhieuBanHang);
            this.Name = "frmPhieuBanHang";
            this.Text = "frmPhieuBanHang";
            this.PhieuBanHang.ResumeLayout(false);
            this.TabPhieuBanHang.ResumeLayout(false);
            this.TabPhieuBanHang.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataPhieuBanHang)).EndInit();
            this.TabChiTietPhieu.ResumeLayout(false);
            this.TabChiTietPhieu.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataChiTietPhieu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl PhieuBanHang;
        private System.Windows.Forms.TabPage TabPhieuBanHang;
        private System.Windows.Forms.TabPage TabChiTietPhieu;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker TPNgayTao;
        private System.Windows.Forms.RadioButton rbutChoXacNhan;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMaKhachHang;
        private System.Windows.Forms.TextBox txtMaNhanVien;
        private System.Windows.Forms.TextBox txtMaThe;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMaPhieu;
        private System.Windows.Forms.DataGridView DataPhieuBanHang;
        private System.Windows.Forms.Button butXoa;
        private System.Windows.Forms.Button butTimKiem;
        private System.Windows.Forms.Button butLamMoi;
        private System.Windows.Forms.Button butSua;
        private System.Windows.Forms.Button butThem;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button butTimKiem2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button butTthem;
        private System.Windows.Forms.TextBox txtTimKiem2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.DataGridView DataChiTietPhieu;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
    }
}